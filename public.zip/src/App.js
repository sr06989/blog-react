import React, { useState } from 'react';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import Home from './components/Home';
import About from './components/About';
import Profile from './components/BlogCreation';
import Admin from './components/Admin';
import Login from './components/Login';
// import Signup from './Signup';
import Navbar from './components/Navbar';
import Logout from './components/Logout';
import BlogCreation from './components/BlogCreation';

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);

  const handleLogout = () => {
    setIsLoggedIn(false);
    setIsAdmin(false);
    window.location.href = '/login';
  };

  return (
    <Router>
      <div>
        <Navbar isLoggedIn={isLoggedIn} isAdmin={isAdmin} />
        <div className="container mt-3">
          <Switch>
            <Route exact path="/" component={Home} />
            <Route path="/about" component={About} />
            <Route path="/profile" component={Profile} />
            <Route path="/create" component={BlogCreation} />
            <Route path="/login">
              <Login setIsLoggedIn={setIsLoggedIn} setIsAdmin={setIsAdmin} />
            </Route>
            {/* <Route path="/signup" component={Signup} /> */}
            <Route path="/logout">
              <Logout handleLogout={handleLogout} />
            </Route>
          </Switch>
        </div>
      </div>
    </Router>
  );
}

export default App;
