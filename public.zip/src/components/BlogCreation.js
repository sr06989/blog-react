import React, { useState } from 'react';

const BlogCreation = () => {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');

  const handleSubmit = (event) => {
    event.preventDefault();
    // send the blog post data to the server or update the state to store the blog post data
  };

  return (
    <div>
      <h1>Create a new blog post</h1>
      <form onSubmit={handleSubmit}>
        <label htmlFor="title">Title:</label>
        <input type="text" id="title" value={title} onChange={(event) => setTitle(event.target.value)} />
        <label htmlFor="content">Content:</label>
        <textarea id="content" value={content} onChange={(event) => setContent(event.target.value)} />
        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

export default BlogCreation;
