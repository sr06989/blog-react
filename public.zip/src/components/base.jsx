import React from 'react';
import { Link } from 'react-router-dom';

function Base() {
  return (
    <>
      <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
        <Link className="navbar-brand" to="/">Blog IT</Link>
        <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarText">
          <ul className="navbar-nav mr-auto">
            <li className="nav-item active">
              <Link className="nav-link" to="/">Home <span className="sr-only">(current)</span></Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/about">About</Link>
            </li>
            {/* Add profile and create blog entry links when user is authenticated */}
            {user.isAuthenticated ?
              <>
                <li className="nav-item">
                  <Link className="nav-link" to="/profile">Profile</Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to="/blog/create">Create Blog Entry</Link>
                </li>
              </>
              :
              <>
                <li className="nav-item">
                  <Link className="nav-link" to="/login">Login</Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to="/register">Register</Link>
                </li>
              </>
            }
            {/* Always display the logout link if the user is authenticated */}
            {user.isAuthenticated &&
              <li className="nav-item">
                <Link className="nav-link" to="/logout">Logout</Link>
              </li>
            }
          </ul>
          <span className="navbar-text">
            Personal Blog App!
          </span>
        </div>
      </nav>
      <main role="main" className="container" style={{maxWidth: '800px', margin: '0 auto'}}>
        <div className="row">
          <div className="col-md-8">
            {/* Display any messages from the server */}
            {messages &&
              messages.map((message, index) => (
                <div key={index} className={`alert alert-${message.tags}`}>
                  {message}
                </div>
              ))
            }
            {/* Render the content of each page */}
            {props.children}
          </div>
        </div>
      </main>
    </>
  );
}

export default Base;
