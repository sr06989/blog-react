import React from "react";
import "./about.css";

const About = () => {
  return (
    <div className="container">
      <h1>About Us</h1>
      <p>Welcome esteemed visitors to our literary enclave! Our identity is that of Alina and Samin, and we are the virtuoso behind this digital terrain. We are students, but during our leisure, we pen our thoughts on different topics and share them with the world.</p>
      <p>In 2023, we launched this online sanctuary to connect with like-minded connoisseurs, and furnish a stage for expressing our reflections and experiences. Since then, our blog has flourished into a thriving congregation of many readers, and it is still counting.</p>
      <h2>What You Can Expect from Our Blog?</h2>
      <p>Our blog encompasses an extensive range of literature pertaining to technology, art to everything hip! We craft our work on many topics while continually exploring novel concepts and viewpoints. Our objective is to create captivating, thought-provoking, and informative content for our readers.</p>
      <p>We firmly believe in fostering a sense of community on our blog.</p>
      <h2>Connect with us</h2>
      <p>If you have any queries or comments, please feel free to contact us at writeussomething@something.com</p>
    </div>
  );
};

export default About;

