import React from 'react';

const Home = () => {
  return (
    <div>
      <h1>Welcome to my blog!</h1>
      <p>This is my personal blog where I write about my thoughts and experiences.</p>
    </div>
  );
};

export default Home;
