import React from 'react';

const Admin = () => {
  return (
    <div>
      <h1>Welcome, Admin!</h1>
      <p>You have full access to all the features and functionalities of the application.</p>
      <ul>
        <li>Manage users</li>
        <li>Manage content</li>
        <li>View analytics</li>
        <li>etc.</li>
      </ul>
    </div>
  );
};

export default Admin;
