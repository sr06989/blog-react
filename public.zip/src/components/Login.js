import React, { useState } from 'react';
import { useHistory } from 'react-router-dom';

const users = [
  {
    username: 'admin',
    password: 'admin',
    role: 'admin',
  },
  {
    username: 'user',
    password: 'user',
    role: 'normal',
  },
];

const Login = ({ isLoggedIn, setIsLoggedIn, isAdmin, setIsAdmin }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const history = useHistory();

  const handleLogin = (e) => {
    e.preventDefault();
    const user = users.find(u => u.username === username && u.password === password);
    if (user) {
      setIsLoggedIn(true);
      setIsAdmin(user.role === 'admin');
      history.push('/');
    } else {
      alert('Invalid credentials');
    }
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setIsAdmin(false);
    history.push('/login');
  };

  return (
    <div className="content-section">
      {isLoggedIn ?
        <div>
          <p>You are already logged in.</p>
          <button className="btn btn-outline-info" onClick={handleLogout}>Log out</button>
        </div>
        :
        <div>
          <form onSubmit={handleLogin}>
            <fieldset className="form-group">
              <legend className="border-bottom mb-4">Login Here</legend>
              <div className="form-group">
                <label htmlFor="username">Username:</label>
                <input
                  type="text"
                  className="form-control"
                  id="username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                />
              </div>
              <div className="form-group">
                <label htmlFor="password">Password:</label>
                <input
                  type="password"
                  className="form-control"
                  id="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>
              <button className="btn btn-outline-info" type="submit">Log in</button>
            </fieldset>
          </form>
          <div className="border-top pt-3">
            <small className="text-muted">
              Need an account? <a className="ml-2" href="/signup">Sign Up</a>
            </small>
          </div>
        </div>
      }
    </div>
  );
};

export default Login;
