import React from 'react';

const Profile = () => {
  return (
    <div>
      <h1>My Profile</h1>
      <p>Username: [Your Username]</p>
      <p>Email: [Your Email]</p>
      <p>Interests: [Your Interests]</p>
    </div>
  );
};

export default Profile;
