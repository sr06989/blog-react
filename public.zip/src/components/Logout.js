import React from 'react';
import { Link } from 'react-router-dom';

const Logout = ({ handleLogout }) => {
  return (
    <div>
      <div className="border-top pt-3">
        <small className="text-muted">
          <Link to="/" onClick={handleLogout}>Logout</Link>
        </small>
      </div>
    </div>
  );
};

export default Logout;
